import { useInitAnimations } from '../hooks/use-init-animations';

const InitAnimations = () => {
  useInitAnimations();
  return null;
};

export default InitAnimations;
